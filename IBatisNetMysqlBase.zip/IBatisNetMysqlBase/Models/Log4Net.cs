﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using log4net;
using log4net.Config;

public class Log4Net
{
    private static object syncLock = new object();
    private static ILog uniq = null;

    public static ILog I
    {
        get
        {
            try
            {
                if (uniq == null)
                {
                    lock (syncLock)
                    {
                        if (uniq == null)
                        {
                            uniq = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
            return uniq;
        }
    }
}