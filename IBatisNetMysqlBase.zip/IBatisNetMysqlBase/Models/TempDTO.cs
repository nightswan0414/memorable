﻿using System;

public class TempDTO
{
    public TempDTO()
    {
        this.id = 0;
        this.data = null;
    }

    public TempDTO(int id = 0, string data = null)
    {
        this.id = id;
        this.data = data;
    }

    public int id { get; set; }
    public string data { get; set; }
}