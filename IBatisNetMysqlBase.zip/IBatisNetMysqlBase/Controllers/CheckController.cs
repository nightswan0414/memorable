﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using log4net;
using log4net.Config;

using IBatisNet.DataMapper;
using IBatisNet.Common.Utilities;
using IBatisNet.DataMapper.Configuration;

namespace MybatisApp01.Controllers
{
    public class CheckController : Controller
    {
        public ActionResult Log4JConfig()
        {
            ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            logger.Debug("HelloWorld2");

            string result = "";
            return Content(result, System.Net.Mime.MediaTypeNames.Text.Plain);
        }

        public ActionResult IBatisConfig()
        {
            DomSqlMapBuilder dom = new DomSqlMapBuilder();
            ISqlMapper sqlMapClient = dom.Configure("IBatis/SqlMap.config");
            string r = sqlMapClient.QueryForObject<string>("ConfigTest.NOW", null);

            return Content("ConfigCheckController::MybatisConfig " + r, 
                System.Net.Mime.MediaTypeNames.Text.Plain);
        }
    }
}
